XhinkingTodo v1.0.2
=======================

A modern desktop todo application.

Installation:
  ./install.sh     - Install to user directory (~/.local/bin)

Uninstallation:
  ./uninstall.sh   - Remove XhinkingTodo from your system

Manual Installation:
  1. Copy 'xhinkingtodo' to a directory in your PATH
  2. Copy 'xhinkingtodo.desktop' to ~/.local/share/applications/
  3. Copy icons to ~/.local/share/icons/hicolor/

Requirements:
  - libwebkit2gtk-4.0
  - libgtk-3
  - libappindicator3 (optional, for system tray)

Website: https://github.com/your-repo/XhinkingTodo
