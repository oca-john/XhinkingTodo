#!/bin/bash
#
# Uninstall script for XhinkingTodo
# Removes executable, icons, and desktop entry
#

set -e

PRODUCT_NAME_LOWER="xhinkingtodo"

# Directories
USER_BIN="$HOME/.local/bin"
USER_APPS="$HOME/.local/share/applications"
USER_ICONS="$HOME/.local/share/icons/hicolor"

echo "Uninstalling XhinkingTodo..."

# Remove executable
if [ -f "$USER_BIN/$PRODUCT_NAME_LOWER" ]; then
    rm -f "$USER_BIN/$PRODUCT_NAME_LOWER"
    echo "  Removed $USER_BIN/$PRODUCT_NAME_LOWER"
fi

# Remove icons
rm -f "$USER_ICONS/128x128/apps/$PRODUCT_NAME_LOWER.png"
rm -f "$USER_ICONS/512x512/apps/$PRODUCT_NAME_LOWER.png"
echo "  Removed icons from $USER_ICONS"

# Remove desktop entry
if [ -f "$USER_APPS/$PRODUCT_NAME_LOWER.desktop" ]; then
    rm -f "$USER_APPS/$PRODUCT_NAME_LOWER.desktop"
    echo "  Removed $USER_APPS/$PRODUCT_NAME_LOWER.desktop"
fi

# Update icon cache
if command -v gtk-update-icon-cache &> /dev/null; then
    gtk-update-icon-cache -f -t "$USER_ICONS" 2>/dev/null || true
fi

echo ""
echo "Uninstallation completed successfully!"
