#!/bin/bash
#
# Install script for XhinkingTodo
# Installs to user's local bin and applications directories
#

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PRODUCT_NAME_LOWER="xhinkingtodo"

# Directories
USER_BIN="$HOME/.local/bin"
USER_APPS="$HOME/.local/share/applications"
USER_ICONS="$HOME/.local/share/icons/hicolor"

echo "Installing XhinkingTodo..."

# Create directories
mkdir -p "$USER_BIN"
mkdir -p "$USER_APPS"
mkdir -p "$USER_ICONS/128x128/apps"
mkdir -p "$USER_ICONS/512x512/apps"

# Copy executable
cp "$SCRIPT_DIR/$PRODUCT_NAME_LOWER" "$USER_BIN/"
chmod +x "$USER_BIN/$PRODUCT_NAME_LOWER"
echo "  Installed executable to $USER_BIN/$PRODUCT_NAME_LOWER"

# Copy icons
if [ -f "$SCRIPT_DIR/${PRODUCT_NAME_LOWER}_128.png" ]; then
    cp "$SCRIPT_DIR/${PRODUCT_NAME_LOWER}_128.png" "$USER_ICONS/128x128/apps/$PRODUCT_NAME_LOWER.png"
fi
if [ -f "$SCRIPT_DIR/$PRODUCT_NAME_LOWER.png" ]; then
    cp "$SCRIPT_DIR/$PRODUCT_NAME_LOWER.png" "$USER_ICONS/512x512/apps/$PRODUCT_NAME_LOWER.png"
fi
echo "  Installed icons to $USER_ICONS"

# Create desktop entry with correct paths
cat > "$USER_APPS/$PRODUCT_NAME_LOWER.desktop" << EOF
[Desktop Entry]
Name=XhinkingTodo
Comment=A modern desktop todo application
Exec=$USER_BIN/$PRODUCT_NAME_LOWER
Icon=$PRODUCT_NAME_LOWER
Terminal=false
Type=Application
Categories=Office;TextEditor;Utility;
Keywords=todo;task;productivity;
StartupWMClass=$PRODUCT_NAME_LOWER
EOF
chmod +x "$USER_APPS/$PRODUCT_NAME_LOWER.desktop"
echo "  Installed desktop entry to $USER_APPS/$PRODUCT_NAME_LOWER.desktop"

# Update icon cache
if command -v gtk-update-icon-cache &> /dev/null; then
    gtk-update-icon-cache -f -t "$USER_ICONS" 2>/dev/null || true
fi

# Ensure ~/.local/bin is in PATH
if [[ ":$PATH:" != *":$USER_BIN:"* ]]; then
    echo ""
    echo "NOTE: Please add $USER_BIN to your PATH:"
    echo "  echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ~/.bashrc"
    echo "  source ~/.bashrc"
fi

echo ""
echo "Installation completed successfully!"
echo "You can now run XhinkingTodo from your application menu or by typing '$PRODUCT_NAME_LOWER'"
